import streamlit as st
import pandas as pd
import numpy as np
import pickle
import os

st.sidebar.title("Navigation")
app_mode = st.sidebar.selectbox("Choose a page", ["Home", "Prediction"])

@st.cache_data
def load_data():
    try:
        return pd.read_csv("test.csv")
    except FileNotFoundError:
        return None

def get_fvalue(val):
    feature_dict = {"No": 1, "Yes": 2}
    return feature_dict.get(val, 0)

def get_value(val, my_dict):
    return my_dict.get(val, 0)

if app_mode == "Home":
    st.title("Loan Prediction Web App")
    data = load_data()
    if data is not None:
        st.write("### Sample Data")
        st.write(data.head())
        st.write("### Income vs Loan Amount")
        st.bar_chart(data[["ApplicantIncome", "LoanAmount"]].head(20))
    else:
        st.warning("Dataset not found. Please upload 'test.csv'.")

elif app_mode == "Prediction":
    st.title("Loan Eligibility Predictor")

    st.sidebar.subheader("Client Information")

    gender_dict = {"Male": 1, "Female": 2}
    feature_dict = {"No": 1, "Yes": 2}
    edu = {"Graduate": 1, "Not Graduate": 2}
    prop = {"Rural": 1, "Urban": 2, "Semiurban": 3}

    ApplicantIncome = st.sidebar.slider('Applicant Income', 0, 10000, 0)
    CoapplicantIncome = st.sidebar.slider('Coapplicant Income', 0, 10000, 0)
    LoanAmount = st.sidebar.slider('Loan Amount (in K$)', 9.0, 700.0, 200.0)
    Loan_Amount_Term = st.sidebar.selectbox('Loan Term', (12.0, 36.0, 60.0, 84.0, 120.0, 180.0, 240.0, 300.0, 360.0))
    Credit_History = st.sidebar.radio('Credit History', (0.0, 1.0))
    Gender = st.sidebar.radio('Gender', list(gender_dict.keys()))
    Married = st.sidebar.radio('Married', list(feature_dict.keys()))
    Self_Employed = st.sidebar.radio('Self Employed', list(feature_dict.keys()))
    Dependents = st.sidebar.radio('Dependents', ['0', '1', '2', '3+'])
    Education = st.sidebar.radio('Education', list(edu.keys()))
    Property_Area = st.sidebar.radio('Property Area', list(prop.keys()))

    # One-hot encoding for Dependents
    class_0 = class_1 = class_2 = class_3 = 0
    if Dependents == '0':
        class_0 = 1
    elif Dependents == '1':
        class_1 = 1
    elif Dependents == '2':
        class_2 = 1
    else:
        class_3 = 1

    Rural = Urban = Semiurban = 0
    if Property_Area == 'Urban':
        Urban = 1
    elif Property_Area == 'Semiurban':
        Semiurban = 1
    else:
        Rural = 1

    feature_list = [
        ApplicantIncome, CoapplicantIncome, LoanAmount, Loan_Amount_Term,
        Credit_History, get_value(Gender, gender_dict), get_fvalue(Married),
        class_0, class_1, class_2, class_3,
        get_value(Education, edu), get_fvalue(Self_Employed),
        Rural, Urban, Semiurban
    ]

    single_sample = np.array(feature_list).reshape(1, -1)

    if st.button("Predict"):
        if not os.path.exists("RF.sav"):
            st.error("Model file 'RF.sav' not found. Please upload it.")
        else:
            with open("RF.sav", "rb") as f:
                loaded_model = pickle.load(f)
            prediction = loaded_model.predict(single_sample)
            if prediction[0] == 0:
                st.error("According to our model, your loan is likely to be rejected.")
            else:
                st.success("Congratulations! Your loan is likely to be approved.")
